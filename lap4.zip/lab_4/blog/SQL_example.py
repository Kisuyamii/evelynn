# -*- coding: utf-8 -*-

import sqlite3
def sqlite3_simple_example_create_db():
    print(1)
    con=sqlite3.connect('./blog/db_project_name.db')

    cur= con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS articles(Title TEXT,Author TEXT,Text TEXT);""")
    con.commit()

sqlite3_simple_example_create_db()